package controller;

import dao.ClienteImpl;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext; 
import services.ReporteS; 
import model.Cliente;




@Named(value = "ClienteC")
@SessionScoped
public class ClienteC implements Serializable {

    private Cliente cliente;
    private ClienteImpl dao;
    private List<Cliente> lstClientes;
    private List<Cliente> lstUbigeo;

    public ClienteC() {
        cliente = new Cliente();
        dao = new ClienteImpl();
    }

    public void registrar() throws Exception {
        try {
            dao.guardar(cliente);
            
            limpiar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registrado", "Registrado con éxito"));
        } catch (Exception e) {
            System.out.println("Error en registrar ClienteC/registrar: " + e.getMessage());
        }
    }

    public void modificar() throws Exception {
        try {
            dao.modificar(cliente);
            
            limpiar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Modificado", "Registrado con éxito"));
        } catch (Exception e) {
            System.out.println("Error en modificar ClienteC/modificar: " + e.getMessage());
        }
    }

    public void eliminar() throws Exception {
        try {
            dao.eliminar(cliente);
            
            limpiar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Eliminado", "Eliminado con éxito"));
        } catch (Exception e) {
            System.out.println("Error en eliminar PacienteC/modificar: " + e.getMessage());
        }
    }

    public void listar() throws Exception {
        try {
            lstClientes = dao.listarTodos();
        } catch (Exception e) {
            System.out.println("Error en listar ClienteC/modificar: " + e.getMessage());
        }
    }

   

    public void limpiar() {
        cliente = new Cliente();
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public List<Cliente> getLstCliente() {
        return lstClientes;
    }

    public void setLstCliente(List<Cliente> lstCliente) {
        this.lstClientes = lstCliente;
    }

    public ClienteImpl getDao() {
        return dao;
    }

    public void setDao(ClienteImpl dao) {
        this.dao = dao;
    }

    public List<Cliente> getLstClientes() {
        return lstClientes;
    }

    public void setLstClientes(List<Cliente> lstClientes) {
        this.lstClientes = lstClientes;
    }

    public List<Cliente> getLstUbigeo() {
        lstUbigeo = new ArrayList<Cliente>();
        try {
            lstUbigeo = dao.listarUbigeo();
        } catch (Exception e) {
            System.out.println("Error en listarUbigeo controladorCliente" + e.getMessage());
        }
        return lstUbigeo;
    }

    public void setLstUbigeo(List<Cliente> lstUbigeo) {
        this.lstUbigeo = lstUbigeo;
    }

}
