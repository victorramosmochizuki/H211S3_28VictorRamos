package controller;

import dao.EmpleadoImpl;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import model.Empleado;




@Named(value = "EmpleadoC")
@SessionScoped




public class EmpleadoC implements Serializable {

    private Empleado empleado;  
    private EmpleadoImpl dao;
    private List<Empleado> lstEmpleado;
    private List<Empleado> lstUbigeo;


    public EmpleadoC() {
        empleado = new Empleado();
        dao = new EmpleadoImpl();
        lstEmpleado = new ArrayList<>();
    }

    public void registrar() throws Exception {
        try {
            dao.guardar(empleado);
           
            limpiar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registrado", "Registrado con éxito"));
        } catch (Exception e) {
            System.out.println("Error en registrar EmpleadoC/registrar: " + e.getMessage());
        }
    }

    
    
    
    public void modificar() throws Exception {
        try {
            dao.modificar(empleado);
          
            limpiar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Modificado", "Registrado con éxito"));
        } catch (Exception e) {
            System.out.println("Error en modificar EmpleadoC/modificar: " + e.getMessage());
        }
    }

    
    
    
    
    public void eliminar() throws Exception {
        try {
            dao.eliminar(empleado);
            
            limpiar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Eliminado", "Eliminado con éxito"));
        } catch (Exception e) {
            System.out.println("Error en eliminar EmpleadoC/modificar: " + e.getMessage());
        }
    }

    
    
    
    
    public void listar() throws Exception {
        try {
            lstEmpleado = dao.listarTodos();
        } catch (Exception e) {
            System.out.println("Error en listar EmpleadoC/modificar: " + e.getMessage());
        }
    }    

    public void limpiar(){
    empleado = new Empleado();
    }
    
    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public List<Empleado> getLstEmpleado() {
        return lstEmpleado;
    }

    public void setLstEmpleado(List<Empleado> lstEmpleado) {
        this.lstEmpleado = lstEmpleado;
    }

    public EmpleadoImpl getDao() {
        return dao;
    }

    public void setDao(EmpleadoImpl dao) {
        this.dao = dao;
    }

    public List<Empleado> getLstUbigeo() {
        lstUbigeo = new ArrayList<Empleado>();
        try {
            lstUbigeo = dao.listarUbigeo();
        } catch (Exception e) {
            System.out.println("Error en listarUbigeo controladorEmpleado" + e.getMessage());
        }
        return lstUbigeo;
    }

    public void setLstUbigeo(List<Empleado> lstUbigeo) {
        this.lstUbigeo = lstUbigeo;
    }

    
}

