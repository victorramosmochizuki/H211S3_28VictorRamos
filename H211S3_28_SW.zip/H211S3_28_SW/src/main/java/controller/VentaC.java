package controller;

import dao.VentaImpl;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import model.VentaDetalle;
import model.venta;
import static services.facturaConvert.convertir;


@Named(value = "ventaC")
@SessionScoped
public class VentaC implements Serializable {
    
    private venta venta;
    private VentaImpl dao;
    private List<venta> lstVenta;
    private List<venta> lstEmpleado;
    private List<venta> lstCliente;
    private List<venta> lstMedicamento;
    private List<VentaDetalle> lstVentaDetalle;
    
    
    public VentaC() {
        venta = new venta();
        dao = new VentaImpl();
        lstVentaDetalle = new ArrayList<>();
    }

    
    public void registrar() throws Exception {
        try {
            int id;
            if (venta != null) {
                id = dao.guardars(venta);
                venta.setIDventa(id);
                lstVentaDetalle.stream().map((detalle) -> {
                    System.out.println(detalle.getIDProd());
                venta ventaDetalle = new venta();
                ventaDetalle.setIDventa(id);
                ventaDetalle.setIDprod(detalle.getIDProd());
                ventaDetalle.setCantProd(detalle.getCantProd());
                    System.out.println(ventaDetalle.getIDprod());
                    return ventaDetalle; 
                }).forEach(dao::guardarDetalle);
                
            }

 
            
           lstVentaDetalle.clear();
            limpiar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registrado", "Registrado con éxito"));
        } catch (Exception e) {
            System.out.println("Error en registrar ClienteC/registrar: " + e.getMessage());
        }
    }
    
    public void modificar() throws Exception {
        try {
            dao.modificar(venta);
            if (venta != null) {
                dao.modificarDetalle(venta);
            }
          
            
            
            limpiar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Modificado", "Registrado con éxito"));
        } catch (Exception e) {
            System.out.println("Error en modificar ClienteC/modificar: " + e.getMessage());
        }
    }
    
    public void eliminar() throws Exception {
        try {
            dao.eliminar(venta);
            if (venta != null) {
                dao.eliminarDetalle(venta);
            }
            limpiar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Eliminado", "Eliminado con éxito"));
        } catch (Exception e) {
            System.out.println("Error en eliminar ClienteC/modificar: " + e.getMessage());
        }
    }
    
    public void listar() throws Exception {
        System.out.println("corrige2");
        try {
            lstVenta = dao.listarTodos();
           
            
        } catch (Exception e) {
            System.out.println("Error en listar ClienteC/modificar: " + e.getMessage());
        }
    }
    
    
    public void agregarFila() {
        System.out.println("corrige");
        try {


                VentaDetalle detalle = new VentaDetalle(); 
                detalle.setFactVenTemp(convertir(venta.getIDventa()));
                detalle.setIDProd(venta.getIDprod());
                detalle.setCantProd(venta.getCantProd());
                String nombreMedicamento = lstMedicamento.stream()
                        .filter((medicamento) -> medicamento.getIDprod() == venta.getIDprod())
                        .findFirst().map(med-> med.getNomMedicamento())
                        .orElse("Desconocido");
                detalle.setNomMedicamento(nombreMedicamento);
                lstVentaDetalle.add(detalle);
                detalle = new VentaDetalle();
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "HECHO", "Detalle añadido"));
               

                
                
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "ERROR", "Ingrese correctamente los datos"));
            e.printStackTrace();
           
        }

    }

    
    
    
    
    
    public void limpiar() {
        venta = new venta();
    }
    
    public venta getVenta() {
        return venta;
    }
    
    public void setVenta(venta venta) {
        this.venta = venta;
    }
    
    public VentaImpl getDao() {
        return dao;
    }
    
    public void setDao(VentaImpl dao) {
        this.dao = dao;
    }
    
    public List<venta> getLstVenta() {
        return lstVenta;
    }
    
    public void setLstVenta(List<venta> lstVenta) {
        this.lstVenta = lstVenta;
    }

    public List<venta> getLstEmpleado() {
        lstEmpleado = new ArrayList<venta>();
        try {
            lstEmpleado =dao.listarEmpleado();
        } catch (SQLException e) {
            System.out.println("Error en lstEmpleado" + e.getMessage());
        }catch(Exception e){
            System.out.println("Error en lstEmpleado" + e.getMessage());
        }
        return lstEmpleado;
    }

    public void setLstEmpleado(List<venta> lstEmpleado) {
        this.lstEmpleado = lstEmpleado;
    }

    public List<venta> getLstCliente() {
        lstCliente = new ArrayList<venta>();
        try {
            lstCliente =dao.listarCliente();
        } catch (SQLException e) {
            System.out.println("Error en lstCliente" + e.getMessage());
        }catch(Exception e){
        System.out.println("Error en lstCliente" + e.getMessage());        
        }
        return lstCliente;
    }

    public void setLstCliente(List<venta> lstCliente) {
        this.lstCliente = lstCliente;
    }
    
    public void eliminarFila(VentaDetalle ventaD){
        try {
            lstVentaDetalle.remove(ventaD);
        } catch (Exception e) {
            System.out.println("Error en eliminarFila" + e.getMessage());
        }
    } 
    
    public List<venta> getLstMedicamento() {
        lstMedicamento = new ArrayList<venta>();
        try {
            lstMedicamento =dao.listarMedicamento();
        } catch (SQLException e) {
            System.out.println("Error en lstMedicamento" + e.getMessage());
        }catch (Exception e){
            System.out.println("Error en lstMedicamento" + e.getMessage());
        }
        return lstMedicamento;
    }

    public void setLstMedicamento(List<venta> lstMedicamento) {
        this.lstMedicamento = lstMedicamento;
    }

    public List<VentaDetalle> getLstVentaDetalle() {
        return lstVentaDetalle;
    }

    public void setLstVentaDetalle(List<VentaDetalle> lstVentaDetalle) {
        this.lstVentaDetalle = lstVentaDetalle;
    }
    
}
