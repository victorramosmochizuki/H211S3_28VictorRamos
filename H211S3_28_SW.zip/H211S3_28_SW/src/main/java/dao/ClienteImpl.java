package dao;

import java.util.List;
import model.Cliente;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import services.UtilToSql;


public class ClienteImpl extends Conexion implements ICRUD<Cliente> {

    @Override
    public void guardar(Cliente cliente) throws Exception {
        try {
            String sql = "INSERT INTO CLIENTE"
                    + " (NOMCLI, APECLI, DNICLI, TELCLI, GMLCLI, CODUBI)"
                    + " values (?,?,?,?,?,?) ";
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            ps.setString(1, cliente.getNOMCLI());
            ps.setString(2, cliente.getAPECLI());
            ps.setInt(3, cliente.getDNICLI());
            ps.setInt(4, cliente.getTELCLI());
            ps.setString(5, cliente.getGMLCLI());
            ps.setInt(6, cliente.getCODUBI());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            System.out.println("Error en ClienteImpl/registrar: " + e.getMessage());
        
        }
    }

    @Override
    public void modificar(Cliente cliente) throws Exception {
        try {
            String sql = "update CLIENTE set NOMCLI=?,APECLI=?,DNICLI=?,TELCLI=?,GMLCLI=?,CODUBI=? where IDCLI=?";
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            ps.setString(1, cliente.getNOMCLI());
            ps.setString(2, cliente.getAPECLI());
            ps.setInt(3, cliente.getDNICLI());
            ps.setInt(4, cliente.getTELCLI());
            ps.setString(5, cliente.getGMLCLI());
            ps.setInt(6, cliente.getCODUBI());
            ps.setInt(7, cliente.getIDCLI());
            ps.executeUpdate();
            ps.close();
            
        } catch (Exception e) {
            System.out.println("Error en ClienteImpl/modificar: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(Cliente cliente) throws Exception {
        try {
            String sql = "delete from cliente where IDCLI=?";
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            ps.setInt(1, cliente.getIDCLI());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error en ClienteImpl/eliminar: " + e.getMessage());
        }
    }


    @Override
    public List<Cliente> listarTodos() throws Exception {
        List<Cliente> lista = new ArrayList<>();
        ResultSet rs;
        String sql = "select * from CLIENTE order by IDCLI desc";
        try {
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Cliente cli = new Cliente();
                cli.setIDCLI(rs.getInt("IDCLI"));
                cli.setNOMCLI(rs.getString("NOMCLI"));
                cli.setAPECLI(rs.getString("APECLI"));
                cli.setDNICLI(rs.getInt("DNICLI"));
                cli.setTELCLI(rs.getInt("TELCLI"));
                cli.setGMLCLI(rs.getString("GMLCLI"));
                cli.setCODUBI(rs.getInt("CODUBI"));
                lista.add(cli);
            }
        } catch (Exception e) {
            System.out.println("");
        } finally {
            this.cerrar();
        }
        return lista;
    }
    
 
    public List<Cliente> listarUbigeo() throws Exception {
        List<Cliente> lista = new ArrayList<>();
        ResultSet rs;
        String sql = "select * from UBIGEO";
        try {
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Cliente cli = new Cliente();
                cli.setCodUbigeo(rs.getInt("CODUBI"));
                cli.setDepUbigeo(rs.getString("DEPUBI"));
                cli.setProvUbigeo(rs.getString("PROVUBI"));
                cli.setDistUbigeo(rs.getString("DISTUBI"));  
                lista.add(cli);
            }
        } catch (Exception e) {
            System.out.println("");
        } finally {
            this.cerrar();
        }
        return lista;
    }
    
}
