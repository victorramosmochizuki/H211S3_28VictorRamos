package dao;

import java.util.List;
import model.Empleado;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import services.UtilToSql;

public class EmpleadoImpl extends Conexion implements ICRUD<Empleado> {

    @Override
    public void guardar(Empleado empleado) throws Exception {
        try {
            String sql = "insert into EMPLEADO"
                    + " (NOMEMP,APEEMP,DNIEMP,USUEMP,PASEMP,TELEMP,CODUBI)"
                    + " values (?,?,?,?,?,?,?)";
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            ps.setString(1, empleado.getNOMEMP());
            ps.setString(2, empleado.getAPEEMP());
            ps.setInt(3, empleado.getDNIEMP());
            ps.setString(4, empleado.getUSUEMP());
            ps.setString(5, empleado.getPASEMP());
            ps.setInt(6, empleado.getTELEMP());
            ps.setInt(7, empleado.getCODUBI());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            System.out.println("Error en EmpleadoImpl/registrar: " + e.getMessage());
        }
    }

    @Override
    public void modificar(Empleado empleado) throws Exception {
        try {
            String sql = "update EMPLEADO set NOMEMP=?,APEEMP=?,DNIEMP=?,USUEMP=?,PASEMP=?,TELEMP=?,CODUBI=? where IDEMP=?";
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            ps.setString(1, empleado.getNOMEMP());
            ps.setString(2, empleado.getAPEEMP());
            ps.setInt(3, empleado.getDNIEMP());
            ps.setString(4, empleado.getUSUEMP());
            ps.setString(5, empleado.getPASEMP());
            ps.setInt(6, empleado.getTELEMP());
            ps.setInt(7, empleado.getCODUBI());
            ps.setInt(8, empleado.getIDEMP());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            System.out.println("Error en EmpleadoImpl/modificar: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(Empleado empleado) throws Exception {
        try {
            String sql = "delete from EMPLEADO where IDEMP=?";
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            ps.setInt(1, empleado.getIDEMP());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error en EmpleadoImpl/eliminar: " + e.getMessage());
        }
    }

    // IDEMP NOMEMP APEEMP DNIEMP USUEMP PASEMP TELEMP CODUBI
    @Override
    public List<Empleado> listarTodos() throws Exception {
        List<Empleado> lista = new ArrayList<>();
        ResultSet rs;
        String sql = "select * from EMPLEADO order by IDEMP desc";
        try {
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Empleado emp = new Empleado();
                emp.setIDEMP(rs.getInt("IDEMP"));
                emp.setNOMEMP(rs.getString("NOMEMP"));
                emp.setAPEEMP(rs.getString("APEEMP"));
                emp.setDNIEMP(rs.getInt("DNIEMP"));
                emp.setUSUEMP(rs.getString("USUEMP"));
                emp.setPASEMP(rs.getString("PASEMP"));
                emp.setTELEMP(rs.getInt("TELEMP"));
                emp.setCODUBI(rs.getInt("CODUBI"));
                lista.add(emp);
            }
        } catch (Exception e) {
            System.out.println("");
        } finally {
            this.cerrar();
        }
        return lista;
    }  
    
    //implementacion del ubigeo
    public List<Empleado> listarUbigeo() throws Exception {
        List<Empleado> lista = new ArrayList<>();
        ResultSet rs;
        String sql = "select * from UBIGEO";
        try {
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Empleado emP = new Empleado();
                emP.setCodUbigeo(rs.getInt("CODUBI"));
                emP.setDepUbigeo(rs.getString("DEPUBI"));
                emP.setProvUbigeo(rs.getString("PROVUBI"));
                emP.setDistUbigeo(rs.getString("DISTUBI"));  
                lista.add(emP);
            }
        } catch (Exception e) {
            System.out.println("");
        } finally {
            this.cerrar();
        }
        return lista;
    }
}

