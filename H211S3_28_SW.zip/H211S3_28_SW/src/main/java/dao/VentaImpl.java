package dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.venta;
import static services.facturaConvert.convertir;

public class VentaImpl extends Conexion implements ICRUD<venta> {

    DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");

    @Override
    public void guardar(venta ven) throws Exception {
        String sql = "INSERT INTO VENTA (FECVEN, IDEMP, IDCLI)values (?,?,?)";
        try (PreparedStatement ps = this.conectar().prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, formatter.format(ven.getFechaVenta()));
            ps.setInt(2, ven.getIDempleado());
            ps.setInt(3, ven.getIDcliente());
            ps.execute();
            ResultSet sa = ps.getGeneratedKeys();
            if (sa.next()) {
                System.out.println("impr " + sa.getLong(1));
            }
        } catch (Exception e) {
            Logger.getGlobal().log(Level.WARNING, "Error al Ingresar VENTA Dao {0} ", e.getMessage());
        }
    }

    public int guardars(venta ven) throws Exception {
        String sql = "INSERT INTO VENTA (FECVEN, IDEMP, IDCLI)values (?,?,?)";
        try (PreparedStatement ps = this.conectar().prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setDate(1, Date.valueOf(ven.getFechaVenta()));
            ps.setInt(2, ven.getIDempleado());
            ps.setInt(3, ven.getIDcliente());
            ps.execute();
            ResultSet sa = ps.getGeneratedKeys();
            if (sa.next()) {
                System.out.println("impr " + sa.getInt(1));
                return sa.getInt(1);
            }
        } catch (Exception e) {
            Logger.getGlobal().log(Level.WARNING, "Error al Ingresar VENTA Dao {0} ", e.getMessage());
        }
        return 0;
    }

    public void guardarDetalle(venta ven) {
        System.out.println(ven.getIDprod());
        System.out.println(ven.getIDventa());

        try {
            String sql = "INSERT INTO VENTA_DETALLE (CANMED, IDPRO, FKIDVEN) values (?,?,?)";
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            ps.setInt(1, ven.getCantProd());
            ps.setInt(2, ven.getIDprod());
            ps.setInt(3, ven.getIDventa());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            Logger.getGlobal().log(Level.WARNING, "Error al Ingresar VENTA DETALLE Dao {0} ", e.getMessage());
        }
    }

    @Override
    public void modificar(venta ven) throws Exception {
        String sql = "update VENTA set FECVEN=?,IDEMP=?,IDCLI=? where IDVEN=?";
        try {
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            ps.setString(1, formatter.format(ven.getFechaVenta()));
            ps.setInt(2, ven.getIDempleado());
            ps.setInt(3, ven.getIDcliente());
            ps.setInt(4, ven.getIDventa());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            Logger.getGlobal().log(Level.WARNING, "Error al modificar Actividad Dao {0} ", e.getMessage());
        } finally {
            this.cerrar();
        }
    }

    public void modificarDetalle(venta ven) throws Exception {
        String sql = "update VENTA_DETALLE set CANMED=?,IDPRO=?,FKIDVEN=? where IDVENDET=?";
        try {

            PreparedStatement ps = this.conectar().prepareStatement(sql);
            ps.setInt(1, ven.getCantProd());
            ps.setInt(2, ven.getIDprod());
            ps.setInt(3, ven.getIDventa());
            ps.setInt(4, ven.getIDventaDet());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            Logger.getGlobal().log(Level.WARNING, "Error al modificar detalle {0} ", e.getMessage());
        } finally {
            this.cerrar();
        }
    }

    public void eliminarDetalle(venta ven) throws Exception {
        try {
            String sql = "delete from VENTA_DETALLE where IDVENDET=?";
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            ps.setInt(1, ven.getIDventaDet());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error en VentaImp/eliminar: " + e.getMessage());
        }
    }

    @Override
    public void eliminar(venta ven) throws Exception {
        try {
            String sql = "delete from VENTA where IDVEN=?";
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            ps.setInt(1, ven.getIDventa());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error en VentaImp/eliminar: " + e.getMessage());
        }
    }

    @Override
    public List<venta> listarTodos() throws Exception {
        List<venta> lista = new ArrayList<>();
        ResultSet rs;
        String sql = "SELECT * FROM VENTA_UNIDA order by IDVEN desc";
        try {
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                venta cli = new venta();
                cli.setIDventa(rs.getInt("IDVEN"));
                cli.setFactVenta(convertir(rs.getInt("IDVEN")));
                cli.setFechaVenta(rs.getDate("FECVEN").toLocalDate());
                cli.setIDempleado(rs.getInt("IDEMP"));
                cli.setIDcliente(rs.getInt("IDCLI"));
                cli.setIDventaDet(rs.getInt("IDVENDET"));
                cli.setCantProd(rs.getInt("CANMED"));
                cli.setIDprod(rs.getInt("IDPRO"));
                cli.setCliente(rs.getString("CLIENTE"));
                cli.setEmpleado(rs.getString("EMPLEADO"));
                cli.setMedicamento(rs.getString("MEDICAMENTO"));
                lista.add(cli);
            }
        } catch (Exception e) {
            System.out.println("Error en VentaImp/Listar: " + e.getMessage());
        } finally {
            this.cerrar();
        }
        return lista;
    }

    public List<venta> listarEmpleado() throws Exception {
        List<venta> listaEmp = new ArrayList<>();
        ResultSet rs;
        String sql = "select IDEMP, NOMEMP, APEEMP FROM EMPLEADO";
        try {
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                venta emp = new venta();
                emp.setIDempleado(rs.getInt("IDEMP"));
                emp.setNomEmpleado(rs.getString("NOMEMP"));
                emp.setApeEmpleado(rs.getString("APEEMP"));
                listaEmp.add(emp);
            }
        } catch (Exception e) {
            System.out.println("Error en VentaImp/Listar: " + e.getMessage());
        } finally {
            this.cerrar();
        }
        return listaEmp;
    }

    public List<venta> listarCliente() throws Exception {
        List<venta> listaCli = new ArrayList<>();
        ResultSet rs;
        String sql = "select IDCLI, NOMCLI, APECLI FROM CLIENTE";
        try {
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                venta cli = new venta();
                cli.setIDcliente(rs.getInt("IDCLI"));
                cli.setNomCliente(rs.getString("NOMCLI"));
                cli.setApeCliente(rs.getString("APECLI"));
                listaCli.add(cli);
            }
        } catch (Exception e) {
            System.out.println("Error en VentaCli/Listar: " + e.getMessage());
        } finally {
            this.cerrar();
        }
        return listaCli;
    }

    public List<venta> listarMedicamento() throws Exception {
        List<venta> listaMed = new ArrayList<>();
        ResultSet rs;
        String sql = "select IDPRO, NOMPRO FROM PRODUCTOS";
        try {
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                venta med = new venta();
                med.setIDprod(rs.getInt("IDPRO"));
                med.setNomMedicamento(rs.getString("NOMPRO"));
                listaMed.add(med);
            }
        } catch (Exception e) {
            System.out.println("Error en VentaMed/Listar: " + e.getMessage());
        } finally {
            this.cerrar();
        }
        return listaMed;
    }
}
