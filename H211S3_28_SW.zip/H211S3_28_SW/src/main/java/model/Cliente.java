package model;

public class Cliente {

    
    
    
    private int IDCLI;
    private String NOMCLI;
    
    private String APECLI;
    private int DNICLI;
    
    private int TELCLI;
    private String GMLCLI; 
    private int CODUBI;


    
    
    private int codUbigeo; 
    private String depUbigeo;
    private String provUbigeo;
    private String distUbigeo;


    public int getIDCLI() {
        return IDCLI;
    }

    public void setIDCLI(int IDCLI) {
        this.IDCLI = IDCLI;
    }

    public String getNOMCLI() {
        return NOMCLI;
    }

    public void setNOMCLI(String NOMCLI) {
        this.NOMCLI = NOMCLI;
    }

    public String getAPECLI() {
        return APECLI;
    }

    public void setAPECLI(String APECLI) {
        this.APECLI = APECLI;
    }

    public int getDNICLI() {
        return DNICLI;
    }

    public void setDNICLI(int DNICLI) {
        this.DNICLI = DNICLI;
    }

    public int getTELCLI() {
        return TELCLI;
    }

    public void setTELCLI(int TELCLI) {
        this.TELCLI = TELCLI;
    }

    public String getGMLCLI() {
        return GMLCLI;
    }

    public void setGMLCLI(String GMLCLI) {
        this.GMLCLI = GMLCLI;
    }

    public int getCODUBI() {
        return CODUBI;
    }

    public void setCODUBI(int CODUBI) {
        this.CODUBI = CODUBI;
    }

    public int getCodUbigeo() {
        return codUbigeo;
    }

    public void setCodUbigeo(int codUbigeo) {
        this.codUbigeo = codUbigeo;
    }

    public String getDepUbigeo() {
        return depUbigeo;
    }

    public void setDepUbigeo(String depUbigeo) {
        this.depUbigeo = depUbigeo;
    }

    public String getProvUbigeo() {
        return provUbigeo;
    }

    public void setProvUbigeo(String provUbigeo) {
        this.provUbigeo = provUbigeo;
    }

    public String getDistUbigeo() {
        return distUbigeo;
    }

    public void setDistUbigeo(String distUbigeo) {
        this.distUbigeo = distUbigeo;
    }
    
    
}
