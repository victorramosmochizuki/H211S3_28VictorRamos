package model;


public class Empleado {
    
    
    
    
    private int    IDEMP;
    private String  NOMEMP;
    private String  APEEMP;
    private int     DNIEMP;
    private String  USUEMP;
    private String  PASEMP;
    private int     TELEMP;
    private int     CODUBI;
    
   
    
    
    
    private int codUbigeo; 
    private String depUbigeo;
    private String provUbigeo;
    private String distUbigeo;
   
    
    

    public int getIDEMP() {
        return IDEMP;
    }

    public void setIDEMP(int IDEMP) {
        this.IDEMP = IDEMP;
    }

    public String getNOMEMP() {
        return NOMEMP;
    }

    public void setNOMEMP(String NOMEMP) {
        this.NOMEMP = NOMEMP;
    }

    public String getAPEEMP() {
        return APEEMP;
    }

    public void setAPEEMP(String APEEMP) {
        this.APEEMP = APEEMP;
    }

    public int getDNIEMP() {
        return DNIEMP;
    }

    public void setDNIEMP(int DNIEMP) {
        this.DNIEMP = DNIEMP;
    }

    public String getUSUEMP() {
        return USUEMP;
    }

    public void setUSUEMP(String USUEMP) {
        this.USUEMP = USUEMP;
    }

    public String getPASEMP() {
        return PASEMP;
    }

    public void setPASEMP(String PASEMP) {
        this.PASEMP = PASEMP;
    }

    public int getTELEMP() {
        return TELEMP;
    }

    public void setTELEMP(int TELEMP) {
        this.TELEMP = TELEMP;
    }

    public int getCODUBI() {
        return CODUBI;
    }

    public void setCODUBI(int CODUBI) {
        this.CODUBI = CODUBI;
    }

    public int getCodUbigeo() {
        return codUbigeo;
    }

    public void setCodUbigeo(int codUbigeo) {
        this.codUbigeo = codUbigeo;
    }

    public String getDepUbigeo() {
        return depUbigeo;
    }

    public void setDepUbigeo(String depUbigeo) {
        this.depUbigeo = depUbigeo;
    }

    public String getProvUbigeo() {
        return provUbigeo;
    }

    public void setProvUbigeo(String provUbigeo) {
        this.provUbigeo = provUbigeo;
    }

    public String getDistUbigeo() {
        return distUbigeo;
    }

    public void setDistUbigeo(String distUbigeo) {
        this.distUbigeo = distUbigeo;
    }

    

  
    
}
