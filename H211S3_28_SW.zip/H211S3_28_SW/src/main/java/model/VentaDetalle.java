package model;


public class VentaDetalle {
    
    private int IDventaDet;
    private int cantProd;
    private String NomMedicamento;
    private int IDProd;
    private String factVenTemp;
    private venta ven = new venta();
    
    public int getIDventaDet() {
        return IDventaDet;
    }

    public void setIDventaDet(int IDventaDet) {
        this.IDventaDet = IDventaDet;
    }

    public venta getVen() {
        return ven;
    }

    public void setVen(venta ven) {
        this.ven = ven;
    }

    public String getNomMedicamento() {
        return NomMedicamento;
    }

    public void setNomMedicamento(String NomMedicamento) {
        this.NomMedicamento = NomMedicamento;
    }

    public String getFactVenTemp() {
        return factVenTemp;
    }

    public void setFactVenTemp(String factVenTemp) {
        this.factVenTemp = factVenTemp;
    }

    public int getCantProd() {
        return cantProd;
    }

    public void setCantProd(int cantProd) {
        this.cantProd = cantProd;
    }

    public int getIDProd() {
        return IDProd;
    }

    public void setIDProd(int IDProd) {
        this.IDProd = IDProd;
    }
    
    
}
