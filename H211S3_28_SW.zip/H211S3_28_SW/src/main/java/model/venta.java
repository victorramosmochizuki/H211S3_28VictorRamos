package model;

import java.time.LocalDate;

public class venta {

    
    
    
    
    private int IDventa;
    private String factVenta;
    private LocalDate fechaVenta;
    private int IDempleado;
    private int IDcliente;

    
    
    private int IDventaDet;
    private int cantProd;
    private int IDprod;
    

    private String Cliente;
    private String Empleado;
    private String Medicamento;
    

    
    private String NomEmpleado;
    private String ApeEmpleado;
    private String NomCliente;
    private String ApeCliente;

    
    
    private String NomMedicamento;
            
    public int getIDventa() {
        return IDventa;
    }

    public void setIDventa(int IDventa) {
        this.IDventa = IDventa;
    }

    public String getFactVenta() {
        return factVenta;
    }

    public void setFactVenta(String factVenta) {
        this.factVenta = factVenta;
    }

   

    public int getIDempleado() {
        return IDempleado;
    }

    public void setIDempleado(int IDempleado) {
        this.IDempleado = IDempleado;
    }

    public int getIDcliente() {
        return IDcliente;
    }

    public void setIDcliente(int IDcliente) {
        this.IDcliente = IDcliente;
    }

    public int getIDventaDet() {
        return IDventaDet;
    }

    public void setIDventaDet(int IDventaDet) {
        this.IDventaDet = IDventaDet;
    }

    

    public String getCliente() {
        return Cliente;
    }

    public void setCliente(String Cliente) {
        this.Cliente = Cliente;
    }

    public String getEmpleado() {
        return Empleado;
    }

    public void setEmpleado(String Empleado) {
        this.Empleado = Empleado;
    }

    public String getMedicamento() {
        return Medicamento;
    }

    public void setMedicamento(String Medicamento) {
        this.Medicamento = Medicamento;
    }

    public String getNomEmpleado() {
        return NomEmpleado;
    }

    public void setNomEmpleado(String NomEmpleado) {
        this.NomEmpleado = NomEmpleado;
    }

    public String getApeEmpleado() {
        return ApeEmpleado;
    }

    public void setApeEmpleado(String ApeEmpleado) {
        this.ApeEmpleado = ApeEmpleado;
    }

    public String getNomCliente() {
        return NomCliente;
    }

    public void setNomCliente(String NomCliente) {
        this.NomCliente = NomCliente;
    }

    public String getApeCliente() {
        return ApeCliente;
    }

    public void setApeCliente(String ApeCliente) {
        this.ApeCliente = ApeCliente;
    }

    public String getNomMedicamento() {
        return NomMedicamento;
    }

    public void setNomMedicamento(String NomMedicamento) {
        this.NomMedicamento = NomMedicamento;
    }

    public LocalDate getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(LocalDate fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public int getCantProd() {
        return cantProd;
    }

    public void setCantProd(int cantProd) {
        this.cantProd = cantProd;
    }

    public int getIDprod() {
        return IDprod;
    }

    public void setIDprod(int IDprod) {
        this.IDprod = IDprod;
    }

}
