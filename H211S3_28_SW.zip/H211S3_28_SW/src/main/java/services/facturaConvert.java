package services;

public class facturaConvert {

    public static void main(String[] args) {
        int id = 6676;
        String idConvertido = "";
        idConvertido = convertir(id);
        
        System.out.println("Mi numero es: " + idConvertido);
    }
    
    
    
    
    

    public static String convertir(int id) { 
        String cadena = "";
        cadena = cadena + id;
        for (int i = 0; i < 8; i++) {
            if (cadena.length() < 8) {
                cadena = "0" + cadena;
            }

        }

        return cadena;

    }

}
